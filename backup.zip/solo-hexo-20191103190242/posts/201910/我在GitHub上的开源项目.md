title: 我在 GitHub 上的开源项目
date: '2019-10-10 18:52:41'
updated: '2019-10-10 18:52:41'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [FaceDetectAccessControl](https://github.com/wangchenhao006/FaceDetectAccessControl) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/wangchenhao006/FaceDetectAccessControl/watchers "关注数")&nbsp;&nbsp;[⭐️`4`](https://github.com/wangchenhao006/FaceDetectAccessControl/stargazers "收藏数")&nbsp;&nbsp;[🖖`5`](https://github.com/wangchenhao006/FaceDetectAccessControl/network/members "分叉数")</span>

虹软智慧校园项目-人脸识别门禁端



---

### 2. [Fivecrowdsourcing-Runner_demo](https://github.com/wangchenhao006/Fivecrowdsourcing-Runner_demo) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/wangchenhao006/Fivecrowdsourcing-Runner_demo/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/wangchenhao006/Fivecrowdsourcing-Runner_demo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/wangchenhao006/Fivecrowdsourcing-Runner_demo/network/members "分叉数")</span>

之前那个runner是根据别人代码改的，修改起来力不从心，所以重新独立写一个。upup！



---

### 3. [solo-blog](https://github.com/wangchenhao006/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/wangchenhao006/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/wangchenhao006/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/wangchenhao006/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://lemon-cat.cn`](http://lemon-cat.cn "项目主页")</span>

wangchenhao006 的个人博客 - 记录精彩的程序人生



---

### 4. [spider_tutorial](https://github.com/wangchenhao006/spider_tutorial) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/wangchenhao006/spider_tutorial/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/wangchenhao006/spider_tutorial/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/wangchenhao006/spider_tutorial/network/members "分叉数")</span>

爬虫练习



---

### 5. [wangchenhao006.github.io](https://github.com/wangchenhao006/wangchenhao006.github.io) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/wangchenhao006/wangchenhao006.github.io/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/wangchenhao006/wangchenhao006.github.io/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/wangchenhao006/wangchenhao006.github.io/network/members "分叉数")</span>





---

### 6. [solidityContractDemo](https://github.com/wangchenhao006/solidityContractDemo) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/wangchenhao006/solidityContractDemo/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/wangchenhao006/solidityContractDemo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/wangchenhao006/solidityContractDemo/network/members "分叉数")</span>

solidity;contract;a simple receivable demo



---

### 7. [AlarmProccessing](https://github.com/wangchenhao006/AlarmProccessing) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/wangchenhao006/AlarmProccessing/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/wangchenhao006/AlarmProccessing/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/wangchenhao006/AlarmProccessing/network/members "分叉数")</span>

告警处理



---

### 8. [android](https://github.com/wangchenhao006/android) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/wangchenhao006/android/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/wangchenhao006/android/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/wangchenhao006/android/network/members "分叉数")</span>

接单



---

### 9. [fivecrowdsourcing_runner](https://github.com/wangchenhao006/fivecrowdsourcing_runner) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/wangchenhao006/fivecrowdsourcing_runner/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/wangchenhao006/fivecrowdsourcing_runner/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/wangchenhao006/fivecrowdsourcing_runner/network/members "分叉数")</span>

众包跑腿 配送端

